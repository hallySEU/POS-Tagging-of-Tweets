package cmu.arktweetnlp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.ArrayList;
import java.util.Scanner;

public class fileProcess {
	static CharsetEncoder asciiEncoder =
		      Charset.forName("US-ASCII").newEncoder(); // or "ISO-8859-1" for ISO Latin 1
	private static final String IS_ENGLISH_REGEX = "^[ \\w \\d \\s \\. \\& \\+ \\- \\, \\! \\@ \\# \\$ \\% \\^ \\* \\( \\) \\; \\\\ \\/ \\| \\< \\> \\\" \\' \\? \\= \\: \\[ \\] ]*$";
	public static ArrayList<String> readFile(String filePath)
			throws FileNotFoundException {
		ArrayList<String> arrayList = new ArrayList<String>();
		FileInputStream fis = new FileInputStream(filePath);
		Scanner scanner = new Scanner(fis);
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			arrayList.add(line);
			System.out.println(line);
		}
		scanner.close();
		return arrayList;
	}

	public static void writeFile(String path, String str) {
		try {
			File file = new File(path);
			if (!file.exists())
				file.createNewFile();
			FileOutputStream out = new FileOutputStream(file, true); // 如果追加方式用true
			StringBuffer sb = new StringBuffer();
			sb.append(str + "\n");
			out.write(sb.toString().getBytes("utf-8"));// 注意需要转换对应的字符集
			out.close();
		} catch (IOException ex) {
			System.out.println(ex.getStackTrace());
		}
	}
	
	public static int countFile(String filePath) throws FileNotFoundException {
		ArrayList<String> arrayList = new ArrayList<String>();
		FileInputStream fis = new FileInputStream(filePath);
		int count = 0;
		Scanner scanner = new Scanner(fis);
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			/*if (asciiEncoder.canEncode(line)) {
				//System.out.println(line);
				//System.out.println(count++);
				//writeFile("F:\\english_Tweet_data.txt", line);
			}else {
				System.out.println(line);
			}*/
			if (isEnglish(line)) {
				writeFile("F:\\english_Tweet_data_1.txt", line);
				System.out.println(line);
			}else {
				
			}
			

		}
		scanner.close();
		return count;
	}

	
	private static boolean isEnglish(String text) {
		if (text == null) {
			return false;
		}
		return text.matches(IS_ENGLISH_REGEX);
	}
	public static void main(String[] args) throws FileNotFoundException {
		int count = countFile("F://tweet_data.txt");
		System.out.println(count);
	}
}
